/**
 * @(#)<PROJECT_NAME>.java
 *
 * JFC Sample application
 *
 * @author 
 * @version 1.00 <%y>/<%m>/<%d>
 */
 
package myprojects.<LPROJECT_NAME>; 

public class <PROJECT_NAME> {
    
    public static void main(String[] args) {
    	
        // Create application frame.
        <PROJECT_NAME>Frame frame = new <PROJECT_NAME>Frame();
        
        // Show frame.
        frame.show();
    }
}
