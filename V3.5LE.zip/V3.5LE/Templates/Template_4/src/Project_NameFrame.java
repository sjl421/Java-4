package myprojects.<LPROJECT_NAME>;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * @(#)<PROJECT_NAME>.java
 *
 * JFC Sample application
 *
 * @author 
 * @version 1.00 <%y>/<%m>/<%d>
 */
public class <PROJECT_NAME>Frame extends JFrame {
    
    /**
     * The constructor.
     */  
     public <PROJECT_NAME>Frame() {
                
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu();
        JMenuItem menuFileExit = new JMenuItem();
        
        menuFile.setText("File");
        menuFileExit.setText("Exit");
        
        // Add action listener.for the menu button
        menuFileExit.addActionListener
        (
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    <PROJECT_NAME>Frame.this.windowClosed();
                }
            }
        ); 
        menuFile.add(menuFileExit);
        menuBar.add(menuFile);
        
        setTitle("<PROJECT_NAME>Frame");
        setJMenuBar(menuBar);
        setSize(new Dimension(400, 400));
        
        // Add window listener.
        this.addWindowListener
        (
            new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    <PROJECT_NAME>Frame.this.windowClosed();
                }
            }
        );  
    }
    
    
    /**
     * Shutdown procedure when run as an application.
     */
    protected void windowClosed() {
    	
    	// TODO: Check if it is safe to close the application
    	
        // Exit application.
        System.exit(0);
    }
}
