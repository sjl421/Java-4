/**
 * AWT Sample application
 *
 * @author 
 * @version 1.00 <%y>/<%m>/<%d>
 */
public class <PROJECT_NAME> {
    
    public static void main(String[] args) {
        // Create application frame.
        <PROJECT_NAME>Frame frame = new <PROJECT_NAME>Frame();
        
        // Show frame
        frame.setVisible(true);
    }
}
