/**
 * @(#)<PROJECT_NAME>.java
 *
 * Sample Applet application
 *
 * @author 
 * @version 1.00 <%y>/<%m>/<%d>
 */
 
import java.awt.*;
import java.applet.*;

public class <PROJECT_NAME> extends Applet {
	
	public void init() {
	}

	public void paint(Graphics g) {
		g.drawString("Welcome to Java!!", 50, 60 );
	}
}